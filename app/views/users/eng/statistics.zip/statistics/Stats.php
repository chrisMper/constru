<body>
<div class='navbar' >
<?php include APPROOT . '/views/inc/navbar.php'; ?>
</div>
<main>


<!-- listing View starts -->
<div class = "list-container">

    <div class="left-mid">
    
    <div class = "left-col">
    
    <img src="<?php echo URLROOT; ?>/img/msg.png">
    </div> 
    <div class = 'mid-col'>
        <table><thead><tr><th class="StatName"></th><th class="StatTh">Views</th><th class="StatTh">Booking</th></tr></thead>
    <tbody><tr><td class="StatName">Hello</td><td class="StatTh">Views</td><td class="StatTh">Booking</td></tr></tbody>    
    </table>
    </div>
</div>


<div class = 'right-col'>

    <table><thead><tr><th>Convertion Rate</th></tr></thead>
    <tbody><tr><td>Convertion Rate</td></tr></tbody>

</table>
    
</div>
       
</div>

<!-- listing View End -->

<!-- listing Table starts -->


<!-- listing Table End -->


</main>
    </body>
    <?php include APPROOT . '/views/inc/footer.php'; ?>
    </html>